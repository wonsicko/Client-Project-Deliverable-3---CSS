# xc_data
This is the starter data for the 2024 SI339 web project. 
You can use pages about athletes, or pages about meets.  Either option is missing a home page.

You can modify the .py files if you want to set up your site differently.
